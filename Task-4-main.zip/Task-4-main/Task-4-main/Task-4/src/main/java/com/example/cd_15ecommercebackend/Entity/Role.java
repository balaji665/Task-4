package com.example.cd_15ecommercebackend.Entity;

public enum Role {
    CUSTOMER,
    SELLER
}
