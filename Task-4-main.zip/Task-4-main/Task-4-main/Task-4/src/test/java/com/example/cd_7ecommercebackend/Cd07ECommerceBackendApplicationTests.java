package com.example.cd_15ecommercebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cd15ECommerceBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
